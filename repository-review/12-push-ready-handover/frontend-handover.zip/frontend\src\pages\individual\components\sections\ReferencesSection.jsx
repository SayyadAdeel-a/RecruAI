import { FiUsers, FiEdit2, FiTrash2 } from "react-icons/fi";
import { ProfileSection as Card } from "../../../../components/profile/ProfileSection";
import SectionHeader from "../SectionHeader";

export default function ReferencesSection({ references, onAdd, onEdit, onRemove }) {
  return (
    <Card>
      <SectionHeader icon={<FiUsers size={18} />} title="References" onAdd={onAdd} />
      {(references || []).length === 0 ? (
        <p className="text-gray-500 text-sm py-4 text-center">No references added yet</p>
      ) : (
        <div className="space-y-4">
          {(references || []).map((ref, index) => (
            <div key={ref.id || index} className="flex items-start justify-between p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-25 transition-colors">
              <div className="flex-1">
                <h4 className="font-medium text-ink">{ref.name}</h4>
                <p className="text-sm text-gray-600">{ref.position} at {ref.company}</p>
                {ref.email && <p className="text-xs text-gray-500">{ref.email}</p>}
              </div>
              <div className="flex gap-2 ml-4">
                <button onClick={() => onEdit("references", ref, index)} className="text-gray-500 hover:text-brand-text transition-colors"><FiEdit2 size={14} /></button>
                <button onClick={() => onRemove("references", index)} className="text-gray-500 hover:text-red-600 transition-colors"><FiTrash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
